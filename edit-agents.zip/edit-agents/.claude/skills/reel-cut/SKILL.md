---
name: reel-cut
description: Edit several Instagram/TikTok reels at the same time — one editor agent per reel, all running in parallel — from folders of raw clips (and optional music) into finished 9:16 videos with matched colour, music cut on the hits, speed ramps, punch-ins, -14 LUFS sound and a cover image. Use when the user asks to edit reels, "תערוך לי רילים", "עריכה במקביל", or drops clips into input/.
---

# Reels in parallel

You are the lead. Each reel gets its own `editor` agent (`.claude/agents/editor.md`), and all of them run **at the same time**. The editors use the helper scripts in `scripts/` and the tested commands in `references/recipes.md`.

## Step 0 — tools (once)

Run `ffmpeg -version` and `python3 --version` (Windows: `python --version`).
- ffmpeg missing → Mac: `brew install ffmpeg` (no Homebrew? first: `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`. It asks for the computer password; tell the user to type it in the terminal). Windows: `winget install --id Gyan.FFmpeg -e`, then restart Claude Code.
- Python missing (Windows only, the Mac has it) → `winget install --id Python.Python.3.12 -e`.
- iPhone clips are usually HDR. Check once: `ffmpeg -hide_banner -h filter=scale | grep -c intent`. If it prints 0 and `ffmpeg -hide_banner -filters | grep -c " zscale "` also prints 0, the ffmpeg is too old to convert HDR properly. Mac: `brew upgrade ffmpeg`. The edit still works without it, with slightly flatter colour.
Explain in one Hebrew line what you are installing and why.

## Step 1 — what is there (you)

Every folder under `input/` is one reel: `input/reel-1/`, `input/reel-2/`, … Inside: video clips (mp4/mov) and optionally ONE music file (mp3/wav/m4a).
- No folders but clips loose in `input/`? Ask how many reels to make and split the clips between folders yourself.
- Empty folder → skip it and say so.

Read the user's options from their message (Hebrew). Ask once, in one short Hebrew message, only if the length is missing (default 12 seconds):

| the user writes | option to pass the editor | default |
|---|---|---|
| `12 שניות`, `20 שניות`, `קצר`=8 | length | 12 s |
| `חם` / `קר` / `נקי` | look warm / cool / clean | clean |
| `3 פתיחות` | hooks 3 → `reel-N_A.mp4`, `_B`, `_C` (different first 1.5 s, same rest) | 1 |
| `בלי מוזיקה` | music no (clip sound only, even if a music file is in the folder) | music if a file is there |
| `בלי פלאש`, `בלי האטה`, `בלי זום` | switch that tool off | on where it fits |
| `לכל הרילים` / `רק לריל 2` | which reels the options apply to | all |

No text is burned into the video: tell the user that headlines are added later in the Instagram/TikTok app with its own text tool, so they look native.

## Step 2 — parallel edit

First `mkdir -p output work`. Then in a SINGLE message launch one `editor` agent per reel folder, so they all run at the same time. Give each one: its folder path, the output path `output/<folder-name>.mp4`, the length and the options.
Do not edit any reel yourself and do not wait for one editor before launching the next.

## Step 3 — report (you)

When all are back, list in Hebrew for each reel: the file path(s), the cover, length, number of shots, music yes/no, loudness, and what the editor chose to open with. With 3 openings, say: upload all three as a test (or post one and use the others for ads) and keep the one that holds viewers best.
Remind them: the cover (`reel-N_cover.jpg`) is set in the app under "Edit cover" → "Add from camera roll". Add the headline in the app (the top third of the opening is left calm for it). If there was no music file, add music or a trending sound in the app.
Open the `output/` folder for the user (`open output` on Mac, `explorer output` on Windows).

## Rules
- Never delete or change files in `input/`.
- Output: 1080×1920, 30fps, H.264 + AAC, BT.709 (SDR), −14 LUFS, `-movflags +faststart`. Uploads straight to Instagram.
