# Music map for cutting: strong hits, the drop, quiet/loud parts. Plain python + ffmpeg (no numpy).
#   python3 .claude/skills/reel-cut/scripts/hits.py MUSIC
#       -> pulse, tempo guesses, loudness map, the drop, every strong hit (seconds in the song)
#   python3 .claude/skills/reel-cut/scripts/hits.py MUSIC --start 13.51 --len 12
#       -> the same hits in REEL time + frame number at 30 fps, from that music start point
# Cut ON these hits. Tempo guesses can be off by 2x or 3:2 on busy tracks; the hit list is the truth.
import sys, subprocess, struct, math

args = sys.argv[1:]
if not args:
    sys.exit("usage: hits.py MUSIC [--start SEC --len SEC]")
music = args[0]
start = float(args[args.index("--start") + 1]) if "--start" in args else None
length = float(args[args.index("--len") + 1]) if "--len" in args else None
SR, H = 11025, 128
fps = SR / H  # ~86 analysis frames per second

def band(af):
    raw = subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-i", music, "-af", af, "-ac", "1",
                          "-ar", str(SR), "-f", "f32le", "-"], capture_output=True).stdout
    n = len(raw) // 4
    if n < SR:
        sys.exit("could not read the music file (is ffmpeg installed? is the file ok?)")
    x = struct.unpack(f"{n}f", raw)
    e = [math.log(1e-4 + sum(v * v for v in x[i:i + H]) / H) for i in range(0, n - H, H)]
    return [max(0.0, e[i] - e[i - 1]) for i in range(1, len(e))], [math.exp(v / 2) for v in e]

lo, rms = band("lowpass=f=200")     # kick / bass
hi, _ = band("highpass=f=2500")     # snare / claps / hats
on = [a + 0.5 * b for a, b in zip(lo, hi)]
mean = sum(on) / len(on)
sd = math.sqrt(sum((v - mean) ** 2 for v in on) / len(on))

# strong hits: local peaks over +-0.12 s, clearly above average, >= 0.25 s apart
w = int(0.12 * fps)
hits = []
for i in range(w, len(on) - w):
    if on[i] == max(on[i - w:i + w + 1]) and on[i] > mean + 1.5 * sd:
        t = (i + 1) / fps
        if not hits or t - hits[-1] >= 0.25:
            hits.append(t)

# pulse = the most common gap between neighbouring hits (robust where autocorrelation is not)
gaps = sorted(round(b - a, 2) for a, b in zip(hits, hits[1:]) if 0.25 <= b - a <= 0.8)
pulse = None
if gaps:
    best = max(gaps, key=lambda g: sum(1 for x in gaps if abs(x - g) <= 0.02))
    near = [x for x in gaps if abs(x - best) <= 0.02]
    pulse = sum(near) / len(near)

# tempo guesses from autocorrelation (for information)
c = [v - mean for v in on]
res = []
for b10 in range(700, 1800, 5):
    bpm = b10 / 10
    lag = 60 * fps / bpm
    l0 = int(lag); f = lag - l0
    s = sum(c[i] * ((1 - f) * c[i + l0] + f * c[i + l0 + 1]) for i in range(len(c) - l0 - 2)) / (len(c) - l0)
    res.append((s, bpm))
res.sort(reverse=True)
top = []
for s, b in res:
    if all(abs(b - t) > 4 for t in top):
        top.append(b)
    if len(top) == 3:
        break

# loudness every 0.5 s (0-9) and the drop = biggest rise into a loud part
half = int(fps / 2)
seg = [sum(rms[k * half:(k + 1) * half]) / half for k in range(len(rms) // half)]
pk = max(seg) or 1
drop, jump = None, 0
for k in range(2, len(seg) - 2):
    j = (seg[k] + seg[k + 1]) / 2 - (seg[k - 2] + seg[k - 1]) / 2
    if j > jump:
        jump, drop = j, k / 2
if drop is not None and hits:
    drop = min(hits, key=lambda t: abs(t - drop))  # snap to the nearest hit

print("song length %.2f s" % (len(rms) / fps))
if pulse:
    print("pulse (most common gap between hits): %.3f s  -> shot lengths of 2, 3 or 4 pulses = %.2f / %.2f / %.2f s"
          % (pulse, 2 * pulse, 3 * pulse, 4 * pulse))
print("tempo guesses (may be 2x or 3:2 off):", ", ".join("%.0f BPM" % b for b in top))
print("loudness every 0.5 s, 0-9:", "".join(str(min(9, int(9 * v / pk))) for v in seg))
if drop is not None:
    print("drop (biggest rise): %.2f s" % drop)
    before = [t for t in hits if t < drop]
    if len(before) >= 4:
        print("suggested music start: %.2f s (4 hits before the drop, so the drop lands on cut 2)" % before[-4])
print("strong hits (song seconds):", " ".join("%.2f" % t for t in hits))

if start is not None:
    end = start + (length or 60) + 0.6
    sel = [t for t in hits if start - 0.01 <= t <= end]
    print("\nfrom start %.2f s: reel_time / frame@30fps  (cut on these frames)" % start)
    for t in sel:
        r = t - start
        mark = "   <- DROP" if drop is not None and abs(t - drop) < 0.01 else ""
        print("  %6.2f s   frame %4d%s" % (r, round(r * 30), mark))
