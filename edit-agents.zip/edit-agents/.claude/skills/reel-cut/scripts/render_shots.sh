#!/usr/bin/env bash
# Renders every row of a shot plan into a finished 1080x1920 / 30 fps segment.
# usage:  bash .claude/skills/reel-cut/scripts/render_shots.sh PLAN.tsv CLIP_DIR OUT_DIR [clean|warm|cool]
#
# PLAN.tsv = tab-separated, first line is the header, one row per shot:
#   id  clip  in  frames  speed  zoom  fx  flash  sound  why
#   id     s01, s02 ... (file name of the segment, sorted = order in the reel)
#   clip   file name inside CLIP_DIR
#   in     start second in the clip
#   frames length of the shot in the REEL at 30 fps (1 s = 30)
#   speed  1 = normal, 1.5-2 = faster (walking, moving), 0.5-0.8 = slow (only on 50/60 fps clips)
#   zoom   1 = normal, 1.10 = punch-in (10 % tighter), push = slow 6 % push-in over the shot
#   fx     where to crop sideways: 0 = left, 0.5 = centre, 1 = right (matters for wide/landscape clips)
#   flash  1 = the shot starts with a 2-frame white flash (max two in a reel)
#   sound  mute = silent (music reels), clip = the clip's own sound with 20 ms fades (speed 1 only)
#   why    free text
#
# Per shot it: turns iPhone HDR (HLG/PQ) into normal SDR, measures the shot and evens out
# brightness/contrast/saturation toward one target so all shots match, adds the look,
# changes speed, crops to 9:16, sharpens only shots that were enlarged, adds the flash,
# tags the file as plain BT.709 and writes OUT_DIR/<id>.mov (H.264 + PCM audio).
set -e
PLAN="$1"; IN="$2"; OUT="$3"; LOOK="${4:-clean}"
[ -f "$PLAN" ] && [ -d "$IN" ] && [ -n "$OUT" ] || { echo "usage: render_shots.sh PLAN.tsv CLIP_DIR OUT_DIR [clean|warm|cool]"; exit 1; }
mkdir -p "$OUT"
case "$LOOK" in
  warm) LK=",colorbalance=rs=0.03:bs=-0.04:rm=0.02:bm=-0.03" ;;
  cool) LK=",colorbalance=rs=-0.03:bs=0.04:rm=-0.02:bm=0.03" ;;
  *)    LK="" ;;
esac

# --- HDR -> SDR: pick what this ffmpeg can do (best first) ---
if ffmpeg -hide_banner -h filter=scale 2>/dev/null | grep -q "intent"; then
  TMODE=sws      # ffmpeg 8+: swscale tone-maps by itself (tested on Homebrew ffmpeg 9)
  TONEMAP="scale=out_transfer=bt709:out_primaries=bt709:out_color_matrix=bt709:out_range=tv:intent=perceptual,format=yuv420p,"
elif ffmpeg -hide_banner -filters 2>/dev/null | grep -q " zscale "; then
  TMODE=zscale   # builds with libzimg (e.g. the Windows gyan.dev builds)
  TONEMAP="zscale=t=linear:npl=203,format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p,"
else
  TMODE=colorspace  # last resort: no real tone-mapping, the levels pass below evens it out
  TONEMAP="colorspace=all=bt709:iall=bt2020:itrc=bt2020-10:fast=1:format=yuv420p,"
fi

calc() { awk "BEGIN{printf \"%.4f\", $1}" </dev/null; }

tail -n +2 "$PLAN" | while IFS=$'\t' read -r id clip in frames speed zoom fx flash sound why; do
  [ -z "$id" ] && continue
  C="$IN/$clip"; [ -f "$C" ] || { echo "MISSING clip $C"; exit 1; }
  trc=$(ffprobe -v error -select_streams v:0 -show_entries stream=color_transfer -of default=nw=1:nk=1 "$C" </dev/null)
  TM=""; case "$trc" in arib-std-b67|smpte2084) TM="$TONEMAP" ;; esac
  [ -n "$TM" ] && [ "$TMODE" = colorspace ] && [ "$trc" = smpte2084 ] && echo "WARNING $clip is HDR10/PQ and this ffmpeg cannot tone-map it well: update ffmpeg (brew upgrade ffmpeg)."
  dur=$(calc "$frames/30"); src=$(calc "$frames/30*$speed+0.15")

  # 1) measure the shot (after the HDR fix) and build a gentle eq toward one target
  EQ=$(ffmpeg -nostdin -v error -ss "$in" -t "$src" -i "$C" -vf "fps=4,${TM}scale=270:-2,format=yuv420p,signalstats,metadata=print:file=-" -f null - |
    awk -F= '/YAVG/{y+=$2;n++} /YLOW/{l+=$2} /YHIGH/{h+=$2} /SATAVG/{s+=$2}
    END{ if(n==0){print "null"; exit} y/=n; l/=n; h/=n; s/=n; if(h-l<1)h=l+1; if(s<0.1)s=0.1;
      c=150/(h-l); if(c<1)c=1; if(c>1.3)c=1.3; if(h>=225 && c>1.05)c=1.05;   # stretch flat shots, never past the whites
      m=128+(y-128)*c; b=(125-m)/219; if(b>0.06)b=0.06; if(b<-0.06)b=-0.06; # pull the average toward 125 (of 16-235)
      sa=18/s; if(sa<1)sa=1; if(sa>1.5)sa=1.5;                               # lift dull colour, never reduce it
      printf "eq=contrast=%.2f:brightness=%.3f:saturation=%.2f", c, b, sa }')

  # 2) geometry: fill 9:16, optional punch-in / push-in
  if [ "$zoom" = push ]; then
    GEO="scale=1080:1920:force_original_aspect_ratio=increase:force_divisible_by=2,crop=1080:1920:(iw-1080)*$fx:(ih-1920)/2,scale=w='trunc(1080*(1+0.06*t/$dur)/2)*2':h=-2:eval=frame,crop=1080:1920:(iw-1080)/2:(ih-1920)/2"
  else
    GEO="scale=trunc(1080*$zoom/2)*2:trunc(1920*$zoom/2)*2:force_original_aspect_ratio=increase:force_divisible_by=2,crop=1080:1920:(iw-1080)*$fx:(ih-1920)/2"
  fi
  # sharpen only shots that get enlarged (narrow/landscape source or zoom)
  read -r cw ch rot <<< "$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height:stream_side_data=rotation -of default=nw=1:nk=1 "$C" </dev/null | tr '\n' ' ')"
  case "$rot" in -90|90|270|-270) t=$cw; cw=$ch; ch=$t ;; esac
  SH=""; if [ "$zoom" != 1 ] || [ "$cw" -lt 1080 ] || [ "$cw" -gt "$ch" ]; then SH=",unsharp=5:5:0.5:5:5:0"; fi
  FL=""; [ "$flash" = 1 ] && FL=",fade=t=in:st=0:d=0.07:color=white"

  # 3) audio: silence, or the clip's own sound with 20 ms fades
  has_a=$(ffprobe -v error -select_streams a -show_entries stream=index -of csv=p=0 "$C" </dev/null | head -1)
  if [ "$sound" = clip ] && [ -n "$has_a" ] && [ "$speed" = 1 ]; then
    AF="[0:a]aresample=48000,aformat=channel_layouts=stereo,atrim=end=$dur,asetpts=PTS-STARTPTS,apad=whole_dur=$dur,volume=-3dB,afade=t=in:d=0.02,afade=t=out:st=$(calc "$dur-0.02"):d=0.02[a]"
  else
    AF="anullsrc=r=48000:cl=stereo,atrim=end=$dur[a]"
  fi

  ffmpeg -nostdin -v error -y -ss "$in" -t "$src" -i "$C" -filter_complex \
    "[0:v]${TM}${EQ}${LK},setpts=(PTS-STARTPTS)/$speed,fps=30,${GEO}${SH}${FL},format=yuv420p,setparams=range=tv:color_primaries=bt709:color_trc=bt709:colorspace=bt709,setsar=1,trim=end_frame=$frames[v];$AF" \
    -map "[v]" -map "[a]" -c:v libx264 -crf 18 -preset medium -maxrate 12M -bufsize 24M \
    -color_range tv -color_primaries bt709 -color_trc bt709 -colorspace bt709 -c:a pcm_s16le "$OUT/$id.mov"
  got=$(ffprobe -v error -count_frames -select_streams v -show_entries stream=nb_read_frames -of default=nw=1:nk=1 "$OUT/$id.mov" </dev/null)
  ok="ok"; [ "$got" = "$frames" ] || ok="SHORT ($got of $frames frames: clip ends too early, move 'in' earlier)"
  echo "$id  $clip  in=$in  ${frames}f  speed=$speed  zoom=$zoom  hdr=${trc:-sdr}($TMODE)  $EQ  $ok"
done
