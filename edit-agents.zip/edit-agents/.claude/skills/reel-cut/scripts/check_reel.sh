#!/usr/bin/env bash
# Self-check of a finished reel.
# usage:  bash .claude/skills/reel-cut/scripts/check_reel.sh OUTPUT.mp4 PLAN.tsv WORK_DIR
# Writes WORK_DIR/edges.jpg (first 3 + last 3 frames of every shot, one row per shot)
#    and WORK_DIR/final.jpg (12 frames over the whole reel),
# prints format, length, loudness (target -14 LUFS, true peak <= -1 dBTP) and blown-out frames.
OUT="$1"; PLAN="$2"; W="$3"
[ -f "$OUT" ] && [ -f "$PLAN" ] && [ -n "$W" ] || { echo "usage: check_reel.sh OUTPUT.mp4 PLAN.tsv WORK_DIR"; exit 1; }
mkdir -p "$W"
exec </dev/null   # nothing below may wait for keyboard input
# cut frames from the plan (column 4 = frames, rows in order) + flash frames
CUTS=$(tail -n +2 "$PLAN" | awk -F'\t' 'NF>3{s+=$4; print s}')
TOTAL=$(echo "$CUTS" | tail -1)
FLASH=$(tail -n +2 "$PLAN" | awk -F'\t' 'NF>3{if($8==1) print s; s+=$4}')
E="between(n\,0\,2)"; ROWS=1
for c in $(echo "$CUTS" | sed '$d'); do E="$E+between(n\,$((c-3))\,$((c+2)))"; ROWS=$((ROWS+1)); done
E="$E+between(n\,$((TOTAL-3))\,$((TOTAL-1)))"
ffmpeg -nostdin -v error -y -i "$OUT" -vf "select='$E',scale=135:-2,tile=6x$ROWS" -frames:v 1 "$W/edges.jpg"
LEN=$(ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 "$OUT")
ffmpeg -nostdin -v error -y -i "$OUT" -vf "fps=12/$LEN,scale=200:-2,tile=6x2" -frames:v 1 "$W/final.jpg"
echo "file:     $OUT"
echo "video:    $(ffprobe -v error -select_streams v:0 -show_entries stream=width,height,r_frame_rate,pix_fmt,color_transfer -of csv=p=0 "$OUT")   (want 1080,1920,30/1,yuv420p,bt709)"
SECS=$(awk -v t="$TOTAL" 'BEGIN{printf "%.2f", t/30}')
echo "length:   $LEN s   (plan: $TOTAL frames = $SECS s)"
ffmpeg -nostdin -i "$OUT" -af ebur128=peak=true -vn -f null - 2>&1 | sed -n '/Summary/,$p' | awk '/ I:/{print "loudness:", $2, $3, "  (want -14 +-1)"} /Peak:/{print "peak:    ", $2, $3, "  (want <= -1.0)"}'
# blown out = the brightest 10 % of the picture sits at pure white; flash frames are expected
BLOWN=$(ffmpeg -nostdin -v error -i "$OUT" -vf "signalstats,metadata=print:key=lavfi.signalstats.YHIGH:file=-" -f null - |
  awk -v fl=" $(echo $FLASH) " '/^frame/{split($1,a,":"); f=a[2]} /YHIGH/{split($0,b,"="); if (b[2]>=233 && index(fl," "f" ")==0 && index(fl," "f-1" ")==0) printf "%s ", f}')
echo "blown-out frames (not counting flashes): ${BLOWN:-none}"
echo "LOOK at $W/edges.jpg and $W/final.jpg now."
