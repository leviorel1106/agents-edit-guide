# Reel recipes (tested)

Every command here was run on real iPhone footage (HLG HDR, 30 and 60 fps, rotated portrait) with Homebrew ffmpeg 9 on a Mac. Paths are relative to the project folder. `R` = the reel name (e.g. `reel-1`), `W` = `work/R`.

**Shell rules that broke things in testing:**
- Put any loop or multi-line job in a `.sh` file and run it with `bash file.sh`. The Mac terminal shell (zsh) does not split `$VAR` into words, so loops typed straight into the terminal silently do the wrong thing.
- Inside any loop, call `ffmpeg -nostdin` and give `ffprobe` `</dev/null`. Otherwise ffmpeg reads the loop's input and eats the next line (file names lose their first letters).
- Read single values with `-of default=nw=1:nk=1`. With `-of csv=p=0`, a trailing comma comes along (`arib-std-b67,`) and comparisons fail.

## 1. Probe a clip

```bash
ffprobe -v error -select_streams v:0 -show_entries stream=width,height,r_frame_rate,color_transfer:stream_side_data=rotation:format=duration -of default=nw=1 CLIP
```
- `color_transfer=arib-std-b67` (HLG, every iPhone video with HDR on) or `smpte2084` (PQ/HDR10) = **HDR**. Without converting it, the clip looks grey and washed out, and the output file gets tagged HDR, so Instagram shows it wrong.
- `rotation=-90` = shot upright: stored 1920×1080, shown 1080×1920. ffmpeg rotates by itself.
- `r_frame_rate=60000/1001` or `60/1` = a 60 fps clip, the only kind that can be slowed down smoothly.

## 2. HDR → normal SDR (which one works on this machine)

Test once per machine:
```bash
ffmpeg -hide_banner -h filter=scale | grep -c intent     # 1 or more = A works (ffmpeg 8+)
ffmpeg -hide_banner -filters | grep -c " zscale "        # 1 = B works
```
| | filter (put FIRST in the chain, before anything else) | note |
|---|---|---|
| A | `scale=out_transfer=bt709:out_primaries=bt709:out_color_matrix=bt709:out_range=tv:intent=perceptual,format=yuv420p` | **tested, works** on Homebrew ffmpeg 9 for HLG and PQ. Real tone-mapping, the sky keeps its gradient. Homebrew has no zscale. |
| B | `zscale=t=linear:npl=203,format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p` | classic recipe for builds with libzimg (Windows gyan.dev "full"). Not available on the test Mac. |
| C | `colorspace=all=bt709:iall=bt2020:itrc=bt2020-10:fast=1:format=yuv420p` | last resort, runs everywhere: right colours, no tone-mapping, so the levels pass in §4 has to even it out. Fine for HLG, poor for PQ, so tell the user to update ffmpeg. |

Tested and rejected on the Mac: `scale_vt` (VideoToolbox) came out too dark. `scale` without `intent=perceptual` clipped the sky to white.
After the conversion, tag the output as SDR: `setparams=range=tv:color_primaries=bt709:color_trc=bt709:colorspace=bt709` at the end of the chain **and** `-color_range tv -color_primaries bt709 -color_trc bt709 -colorspace bt709` on the encoder. Without these the file keeps the HDR tags.

## 3. Looking at clips

Contact sheet, one frame every 0.5 s, 15 s per sheet (`TM` = the §2 filter followed by a comma, or empty for SDR clips):
```bash
ffmpeg -nostdin -v error -y -ss 0 -t 15 -i CLIP -vf "fps=2,${TM}scale=240:-2,format=yuv420p,tile=6x5" -frames:v 1 $W/sheet_NAME_0.jpg
```
Sheet frame k (counting from 0, left to right, top to bottom) ≈ second `ss + k*0.5`. **2 fps hides things that pass in 0.3 s** (a bag swinging past, a lens zoom). Before locking a shot, check its exact range at 10 fps:
```bash
ffmpeg -nostdin -v error -y -ss IN -t 1.6 -i CLIP -vf "fps=10,${TM}scale=120:-2,format=yuv420p,tile=16x1" -frames:v 1 $W/strip_sNN.jpg
```
Hard cuts inside a clip: `ffmpeg -i CLIP -vf "select='gt(scene,0.3)',showinfo" -f null - 2>&1 | grep -o "pts_time:[0-9.]*"`. It does **not** catch a fast zoom or a lens switch (scores stay under 0.1). Those only show up in the strip or the edges sheet: the same scene suddenly bigger or smaller.

## 4. Colour: per-shot levels + look + sharpen (built into render_shots.sh)

Measure the shot's own stretch after the HDR fix:
```bash
ffmpeg -nostdin -v error -ss IN -t DUR -i CLIP -vf "fps=4,${TM}scale=270:-2,format=yuv420p,signalstats,metadata=print:file=-" -f null - \
 | awk -F= '/YAVG/{y+=$2;n++} /YLOW/{l+=$2} /YHIGH/{h+=$2} /SATAVG/{s+=$2} END{print y/n, l/n, h/n, s/n}'
```
YAVG = average brightness, YLOW/YHIGH = darkest/brightest 10 %, SAT = colour strength (values 16–235).
Turn it into one gentle `eq`:
- `contrast = 150/(YHIGH−YLOW)`, kept between 1.00 and 1.30, and at most 1.05 when YHIGH ≥ 225 (the whites are already near the top).
- `brightness = (125 − (128 + (YAVG−128)·contrast)) / 219`, kept between −0.06 and +0.06.
- `saturation = 18/SAT`, kept between 1.00 and 1.50 (it only ever lifts dull colour).
- Result: `eq=contrast=1.21:brightness=-0.060:saturation=1.50`. On the test footage every shot landed at an average of 121–137 with the blacks at 38–82, and the shots matched.

Looks (after the eq): clean = nothing (the default). warm = `colorbalance=rs=0.03:bs=-0.04:rm=0.02:bm=-0.03`. cool = `colorbalance=rs=-0.03:bs=0.04:rm=-0.02:bm=0.03`. A stronger warm turned the skin orange.
Sharpen only shots that get enlarged (displayed width under 1080, a landscape clip, a punch-in or push): `unsharp=5:5:0.5:5:5:0`. On a 1080-wide phone clip it only doubles the grain and the file size.

## 5. Rhythm and motion (columns in plan.tsv, built into render_shots.sh)

- **Speed-up** on walking or getting from place to place: `speed` 1.5–2 (`setpts=(PTS-STARTPTS)/SPEED`). The clip stretch used = frames/30 × speed.
- **Slow-down** on the key moment: `speed` 0.5–0.8, **only on 60 fps clips**. A 30 fps clip at 0.6× stutters (each frame repeats).
- **Speed ramp** = two rows from the same clip back to back, the second starting where the first ends in the clip (fast walk → slow catch). It plays as one continuous move.
- **Punch-in** on a strong hit: split the shot into two rows from the same clip, the second `zoom` 1.10 starting on the hit (`scale` 10 % bigger + centre `crop`). 8 % was too subtle to read on a phone. A jump cut like this is the reliable punch. `zoompan` jitters.
- **Slow push** through a calm shot: `zoom` = `push` (+6 % over the shot, `scale=w='trunc(1080*(1+0.06*t/DUR)/2)*2':h=-2:eval=frame` then a centre crop).
- **Flash** on the drop: `flash` 1 = `fade=t=in:st=0:d=0.07:color=white` (frame 1 white, frame 2 half). Use at most twice per reel.
- Shots 0.4–1.5 s, longer only for the payoff. Never two near-identical shots in a row: a different subject, size or angle every time.

## 6. Music map (hits, drop, start point)

```bash
python3 .claude/skills/reel-cut/scripts/hits.py input/R/MUSIC.mp3                      # overview
python3 .claude/skills/reel-cut/scripts/hits.py input/R/MUSIC.mp3 --start 13.51 --len 12  # cut frames from that start
```
(Windows: `python` instead of `python3`.) Cut on the listed **hits**, not on a calculated BPM grid. On the test track, autocorrelation said 126 BPM and the old detector said 76, while the real pulse was 0.31 s (94 BPM in eighths). The hit list was right both times.
Default structure: music starts at the suggested start (4 hits before the drop), the hook runs until the drop, cut 2 lands on the drop (the flash goes there), and the reel ends on a hit with the music fading over the last beat.

## 7. Render the shots

```bash
bash .claude/skills/reel-cut/scripts/render_shots.sh $W/plan.tsv input/R $W/shots clean   # or warm / cool
```
It prints one line per shot with the HDR mode, the eq it chose and `ok`, or `SHORT` if the clip ran out (move `in` earlier). The script header documents plan.tsv. Example rows (tab-separated):
```
id	clip	in	frames	speed	zoom	fx	flash	sound	why
s01	IMG_9267.MOV	12.15	39	1	1	0.5	0	mute	hook: poodle jumps up on her
s02	IMG_9233.mov	5.80	23	1	1	0.5	1	mute	drop: trainer opens his arms
s06	IMG_9233.mov	1.00	33	1.75	1	0.5	0	mute	trainer walks in, sped up
s08	IMG_9267.MOV	7.20	35	0.6	1	0.5	0	mute	treat bite, slow (60 fps clip)
s09	IMG_9242.mov	0.30	9	1	1	0.5	0	mute	trainer by the sea
s10	IMG_9242.mov	0.60	18	1	1.10	0.5	0	mute	same shot, punch-in on the hit
s11	IMG_9265.MOV	11.60	33	1	push	0.5	0	mute	group wide, slow push
```
`frames` of a shot = (frame of the next cut) − (frame of this cut), from the `hits.py --start` list. The sum = the reel length × 30.

Join (all segments share one format, so this copies with no re-encode):
```bash
ls $W/shots/s*.mov | sed "s|^|file '$PWD/|; s|$|'|" > $W/list.txt
ffmpeg -nostdin -v error -y -f concat -safe 0 -i $W/list.txt -c copy $W/cut.mov
```

## 8. Sound

**a) Music only** (`L` = reel length in seconds, `MS` = music start, `F` = fade = one beat, about 0.6):
```bash
ffmpeg -nostdin -v error -y -ss MS -t L -i MUSIC -af "aresample=48000,aformat=channel_layouts=stereo,afade=t=in:d=0.02,afade=t=out:st=L-F:d=F" -c:a pcm_s16le $W/mix.wav
```
(Write the number for `L-F`. ffmpeg does no maths in options.)

**b) Music + someone talking** (the shot plays with `sound` = mute, and the voice comes in here with a J-cut: it starts `LEAD` = 0.3 s before its picture). `VIN` = the voice's start second in the clip minus LEAD, `VD` = its length plus LEAD, `AT` = milliseconds in the reel where it starts (cut time minus LEAD):
```bash
ffmpeg -nostdin -v error -y -ss MS -t L -i MUSIC -ss VIN -t VD -i SPEECH_CLIP -filter_complex "
[0:a]aresample=48000,aformat=channel_layouts=stereo,afade=t=in:d=0.02,afade=t=out:st=L-F:d=F[mus];
[1:a]aresample=48000,aformat=channel_layouts=stereo,highpass=f=90,afade=t=in:d=0.08,afade=t=out:st=VD-0.1:d=0.1,adelay=AT|AT,apad=whole_dur=L[vox];
[vox]asplit[sc][v2];
[mus][sc]sidechaincompress=threshold=0.05:ratio=4:attack=15:release=350[duck];
[duck][v2]amix=inputs=2:normalize=0:duration=first[a]" -map "[a]" -c:a pcm_s16le $W/mix.wav
```
Tested: the music sits about 12 dB under the voice while he talks and stays at full level everywhere else. `threshold=0.02:ratio=6` buried the music (−22 dB). An L-cut is the same thing the other way round: the voice runs past its picture, so VD gets longer.

**c) No music** (`בלי מוזיקה`): set `sound` = clip on the shots whose own sound you keep (the script adds −3 dB and 20 ms fades at every cut). Then `ffmpeg -nostdin -v error -y -i $W/cut.mov -vn -c:a pcm_s16le $W/mix.wav`. If the clips' own sound is a song, a song chopped at every cut sounds broken, so instead take ONE stretch of the best clip as in (a), with that clip as the "music".

**Loudness: two passes to −14 LUFS** (Instagram), true peak −1.5:
```bash
ffmpeg -nostdin -i $W/mix.wav -af loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json -f null - 2>&1 | sed -n '/^{/,/^}/p' > $W/ln.json
cat > $W/final.sh <<'EOF'
W=$1; OUT=$2; J=$W/ln.json
g(){ grep "\"$1\"" $J | grep -oE -- '-?[0-9.]+' | head -1; }
ffmpeg -nostdin -v error -y -i $W/cut.mov -i $W/mix.wav -map 0:v -map 1:a -c:v copy \
 -af "loudnorm=I=-14:TP=-1.5:LRA=11:measured_I=$(g input_i):measured_TP=$(g input_tp):measured_LRA=$(g input_lra):measured_thresh=$(g input_thresh):offset=$(g target_offset):linear=true,aresample=48000" \
 -c:a aac -b:a 192k -movflags +faststart -shortest $OUT
EOF
bash $W/final.sh $W output/R.mp4
```
Test result: −13.9 LUFS, true peak −1.4 dBFS, 12.03 s, about 19 MB.

## 9. Three openings (`3 פתיחות`)

Same body, same music, three different first shots. **Every hook has the same frame count**, so the hits stay in place. Put the alternative hooks in `$W/hooks.tsv` (ids `hB`, `hC`), render them with the same script into `$W/shots`, then:
```bash
for v in B C; do sed "s|/s01.mov'|/h$v.mov'|" $W/list.txt > $W/list_$v.txt; done   # A = the normal list
```
Join each list into `cut_A/B/C.mov` and run `final.sh` on each (the same mix.wav) → `output/R_A.mp4`, `output/R_B.mp4`, `output/R_C.mp4`. A different first shot changes nothing in the sound, so the mix stays the same.

## 10. Cover

Pick the shot (a clear face or the product, sharp, top third calm enough for a headline). Within THAT shot's frames, find the sharpest one (`blurdetect` numbers only compare within a single shot: a soft background reads as "blur"):
```bash
ffmpeg -nostdin -v error -i output/R.mp4 -vf "select='between(n\,FIRST\,LAST)',blurdetect=block_width=32:block_height=32,metadata=print:key=lavfi.blur:file=-" -f null - \
 | awk '/^frame/{split($0,a,"pts_time:"); t=a[2]} /blur=/{split($0,b,"="); print t, b[2]}' | sort -k2 -n | head -1
ffmpeg -nostdin -v error -y -ss TIME -i output/R.mp4 -frames:v 1 -q:v 2 output/R_cover.jpg
```
Taking it from the finished video keeps the cover's colour and crop identical to the reel. LOOK at it.

## 11. Self-check

```bash
bash .claude/skills/reel-cut/scripts/check_reel.sh output/R.mp4 $W/plan.tsv $W
```
It prints format, length, loudness and true peak, plus frames whose brightest 10 % is pure white (flash frames excluded). It also writes `edges.jpg` and `final.jpg`. Each row of edges = one shot: its first 3 frames, then its last 3. In the test the edges sheet caught a lens zoom inside a shot and a bag swinging across the opening frames of another. Both were fixed by moving `in`.
